<?php
the_content();
?>