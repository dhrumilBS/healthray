<p>
    <?php
    printf(
        __('The field <b>%s</b> is currently not supported. Please contact support for more information.', 'wp_all_import_plugin'),
        $field['type']
    );
    ?>
</p>