<p class="pmxi-no-fields">
    <?php echo __("No fields found for this group.", 'wp_all_import_plugin'); ?>
</p>